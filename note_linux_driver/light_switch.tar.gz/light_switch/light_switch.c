#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/irq.h>
#include <linux/interrupt.h>
#include <linux/input.h>
#include <linux/of_platform.h>
#include <linux/of_gpio.h>
#include <linux/of_device.h>
#include "drvstd.h"

#define NAME_SIZE               20                                              /**< 名字大小. */
#define NODE_KEY_GPIO           "lightswitch_gpio"                              /**< 节点GPIO键值. */
#define LTSW_NAME_PREFIX        "lightswitch"                                   /**< 光电开关名称前缀. */

#define LTSW_VENDOR             0x0002                                          /**< 厂商信息. */
#define LTSW_PRODUCT            0x0002                                          /**< 产品信息. */
#define LTSW_VERSION            0x0200                                          /**< 版本信息. */

#define KEY_CODE                KEY_ESC                                         /**< 按键码. */

typedef struct _light_switch {
    char name[NAME_SIZE];                                                       /**@ 名字. */
    int id;                                                                     /**@ ID. */
    int pin;                                                                    /**@ 引脚号. */
    int irq;                                                                    /**@ 中断号. */
    struct input_dev *input;                                                    /**@ 对应的input设备. */
}light_switch;

typedef struct _light_switch_priv {
    int count;                                                                  /**@ 已注册的光电开关数量. */
    light_switch ltsw[];                                                        /**@ 光电开关信息. */
}light_switch_priv;

/**************************************************************************************************
 * @brief  : 光电开关中断
 * @param  : 设备
 * @return : 0成功, -1失败
**************************************************************************************************/
static irqreturn_t light_switch_isr(int irq, void *dev)
{
    light_switch *ltsw = dev;

    /* key系统只检测变化按键, 因此需要先报0后报1 */
    input_report_key(ltsw->input, KEY_CODE, 0);
    input_report_key(ltsw->input, KEY_CODE, 1);    
    input_sync(ltsw->input);

#if 0
    /* 调试代码, 用于判断inputx与开关对应关系 */
    pr_info("input = %s\n", dev_name(&ltsw->input->dev));
#endif

    return IRQ_HANDLED;
}

/**************************************************************************************************
 * @brief  : 读取光电开关的状态
 * @param  : 设备
 * @return : 0成功, -1失败
**************************************************************************************************/
static ssize_t light_switch_show_state(struct device *dev, struct device_attribute *attr, char *buf)
{
    struct input_dev *input = to_input_dev(dev);
    light_switch *ltsw = input_get_drvdata(input);
    int state = gpio_get_value(ltsw->pin);
    return sprintf(buf, "%d\n", state);
}

static DEVICE_ATTR(state, 0444, light_switch_show_state, NULL);

/**************************************************************************************************
 * @brief  : 解析光电开关节点数据
 * @param  : 节点
 * @param  : 光电开关信息
 * @param  : 光电开关ID
 * @return : 0成功, -1失败
**************************************************************************************************/
static int parse_light_switch_node(struct device_node *np, light_switch *ltsw, int id)
{
    ltsw->pin  = of_get_named_gpio_flags(np, NODE_KEY_GPIO, 0, NULL);
    ltsw->id   = id;
    ltsw->irq  = gpio_to_irq(ltsw->pin);
    snprintf(ltsw->name, NAME_SIZE, "%s%d", LTSW_NAME_PREFIX, id);

    return 0;
}

/**************************************************************************************************
 * @brief  : 光电开关输入设备创建
 * @param  : 设备
 * @return : 0成功, -1失败
**************************************************************************************************/
static int light_switch_input_init(struct device *parent, light_switch *ltsw)
{
    int ret;
    struct input_dev *input;
    
    /* 申请设备 */
    ltsw->input = devm_input_allocate_device(parent);
    CHECK_R(!ltsw->input, -1, parent, "light switch %d alloc input dev fail", ltsw->id);

    /* 配置INPUT参数 */
    input = ltsw->input;
    input->name = ltsw->name;
    input->phys = ltsw->name;

    /* 设置厂商信息 */
	input->id.bustype = BUS_HOST;
	input->id.vendor  = LTSW_VENDOR;
	input->id.product = LTSW_PRODUCT;
	input->id.version = LTSW_VERSION;

    /* 设置支持的事件 */
    __set_bit(EV_KEY, input->evbit);
    __set_bit(KEY_CODE, input->keybit);

    /* 注册设备 */
    ret = input_register_device(input);
    CHECK_R(!input, -1, parent, "light switch %d alloc input dev fail error:%d", ltsw->id, ret);

    /* 创建属性 */
    ret = device_create_file(&input->dev, &dev_attr_state);
    CHECK_R(ret, -1, parent, "light switch %d create group fail error: %d", ltsw->id, ret);

    /* 保存私有数据 */
    input_set_drvdata(input, ltsw);
    return 0;
}

/**************************************************************************************************
 * @brief  : 光电开关硬件初始化
 * @param  : input设备
 * @param  : 节点信息
 * @return : 0成功, -1失败
**************************************************************************************************/
static int light_switch_hw_init(struct device *parent, light_switch *ltsw)
{
    int ret;

    /* 申请GPIO资源 */
    ret = devm_gpio_request_one(parent, ltsw->pin, GPIOF_DIR_IN, ltsw->name);
    CHECK_R(ret, -1, parent, "light switch request %d pin fail", ltsw->pin);

    /* 申请中断 */
    ret = devm_request_irq(parent, ltsw->irq, light_switch_isr,
                IRQF_TRIGGER_RISING, ltsw->name, ltsw);
    CHECK_R(ret, -1, parent, "light switch request %d irq fail", ltsw->irq);

    return 0;
}

/**************************************************************************************************
 * @brief  : 光电开关设备匹配
 * @param  : 设备
 * @return : 0成功, -1失败
**************************************************************************************************/
static int light_switch_probe(struct platform_device *pdev)
{
    int count, ret, id = 0;
    light_switch *ltsw;
    light_switch_priv *priv;
    struct fwnode_handle *child;
    struct device *dev = &pdev->dev;
    
    /* 获取光电开关数量 */
    count = device_get_child_node_count(&pdev->dev);
    CHECK_R(count <= 0, -1, dev, "not fount light switch dev");
    pr_info("find light switch count = %d\n", count);

    /* 申请私有数据 */
    priv = devm_kzalloc(dev, sizeof(*priv) + sizeof(light_switch) * count, GFP_KERNEL);
    CHECK_R(!priv, -ENOMEM, dev, "light switch alloc priv data fail");

    /* 配置所有节点 */
    device_for_each_child_node(dev, child) {
        ltsw = &priv->ltsw[id];

        /* 解析节点信息 */
        ret = parse_light_switch_node(to_of_node(child), ltsw, id);
        CHECK_RET(ret < 0, ret);

        /* 注册设备 */
        ret = light_switch_input_init(dev, ltsw);
        CHECK_RET(ret < 0, ret);

        /* 初始化硬件 */
        ret = light_switch_hw_init(dev, ltsw);
        CHECK_RET(ret < 0, ret);

        /* 更新ID */
        id++;
    }

    /* 设置私有数据 */
    platform_set_drvdata(pdev, priv);
    pr_info("light switch init success\n");
    return 0;
}

/**************************************************************************************************
 * @brief  : 驱动删除
 * @param  : 设备
 * @return : 0成功, -1失败
**************************************************************************************************/
static int light_switch_remove(struct platform_device *pdev)
{
    light_switch_priv *priv = platform_get_drvdata(pdev);
    light_switch *ltsw;

    /* 删除设备属性文件 */
    for(uint8_t i = 0 ; i < priv->count ; i++) {
        ltsw = &priv->ltsw[i];
        device_remove_file(&ltsw->input->dev, &dev_attr_state);
    }

    return 0;
}

static const struct of_device_id light_switch_match[] = {
	{ .compatible = "light-switch" },
	{},
};
MODULE_DEVICE_TABLE(of, light_switch_match);

static struct platform_driver light_switch_driver = {
    .probe  = light_switch_probe,
    .remove = light_switch_remove,
	.driver	= {
		.name = "lightswitch",
		.of_match_table = of_match_ptr(light_switch_match),
	},
};

module_platform_driver(light_switch_driver);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Li Zheng <lizheng1015@airdoc.com>");
MODULE_DESCRIPTION("light switch driver");
