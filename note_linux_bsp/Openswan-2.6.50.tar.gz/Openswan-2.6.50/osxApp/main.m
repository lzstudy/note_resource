//
//  main.m
//  Openswan
//
//  Created by Jose Quaresma on 15/4/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

/*int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
*/
