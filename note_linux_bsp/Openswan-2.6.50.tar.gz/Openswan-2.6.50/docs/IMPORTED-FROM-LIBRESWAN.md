* pluto: Add support for OID_SHA224_WITH_RSA signatures [Paul]
* added memeq and other shorthands to constants.h
