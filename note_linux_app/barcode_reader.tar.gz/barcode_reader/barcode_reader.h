#ifndef __BARCODE_READER_H__
#define __BARCODE_READER_H__
__BEGIN_DECLS

typedef void (*bcr_cb)(char *code);                                             /**@ 扫码枪回调. */

typedef struct _barcode_reader_ops {
    int (*init)(bcr_cb cb);                                                     /**@ 初始化. */
}barcode_reader_ops;

barcode_reader_ops *get_barcode_reader_ops(void);                               /**# 获取扫码枪操作接口. */

__END_DECLS
#endif
