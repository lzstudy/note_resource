#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <linux/input.h>
#include <sys/wait.h>
#include "halstd.h"
#include "barcode_reader.h"

#define TAG                         "BCR"                                       /**< LOG TAG. */
#define BCR_DEV                     "/dev/input/event15"                         /**< 扫码枪设备. */
#define KEY_SIGNAL                  28                                          /**< 39码 条形码起始标记和结束标记. */

typedef struct _bcr_info {
    uint8_t index;                                                              /**@ code 索引. */
    char code[256];                                                             /**@ code 码. */
    const char *asc;                                                            /**@ 字符集. */
}bcr_info;

typedef struct _barcode_reader_context {
    int fd;                                                                     /**@ 设备描述符. */
    pthread_t pid;                                                              /**@ 线程描述符. */
    bcr_cb report;                                                              /**@ 上报结果. */
    bcr_info info;                                                              /**@ 扫码结果. */
}barcode_reader_context;

static barcode_reader_context bcr_cxt;                                          /**# 扫码枪上下文. */

/* 小写字符集 */
static const char lower_asc[] = {
    '\0', '\0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=',     /* 00 - 13 */
    '\0', '\0', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']',     /* 14 - 27 */
    '\0', '\0', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`',    /* 28 - 41 */
    '\0', '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/'
};

/* 大写字符集 */
static const char upper_asc[] = {
    '\0', '\0', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+',     /* 00 - 13 */
    '\0', '\0', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}',     /* 14 - 27 */
    '\0', '\0', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '"', '~',     /* 28 - 41 */
    '\0', '|', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?'
};

/**************************************************************************************************
 * @brief  : 处理信号键, 扫码枪协议以69键码为起始信号和结束信号
 * @param  : 键码信息
 * @param  : 应用著恶策的回调
 * @param  : 默认字符集
 * @return : None
**************************************************************************************************/
static void process_signal_key(bcr_info *info, bcr_cb bcr_report, const char *default_asc)
{
    /* 接收到结束符, 上报结果 */
    if(info->index > 0)
        bcr_report(info->code);
    
    /* 初始化扫码数据 */
    info->index = 0;
    info->asc = default_asc;
    memset(info->code, 0, sizeof(info->code));
}

/**************************************************************************************************
 * @brief  : 扫码线程入口
 * @param  : None
 * @return : None
**************************************************************************************************/
static void *bcr_thread_entry(void *arg)
{
    struct input_event ie;
    barcode_reader_context *cxt = &bcr_cxt;
    bcr_info *bcrinfo = &cxt->info;
    bcrinfo->asc = lower_asc;

    for(;;)
    {
        read(cxt->fd, &ie, sizeof(ie));

        /* 非条码数据直接返回 */
        if(ie.type != EV_KEY || ie.value == 0)
            continue;

#if 0
        /* 调试代码 */
        LOG_I("type = %d code = %d val = %d", ie.type, ie.code, ie.value);
#endif

        switch(ie.code)
        {
        case KEY_SIGNAL:        /* 处理开始和结束信号 */
            process_signal_key(&cxt->info, cxt->report, lower_asc);
            continue;

        case KEY_LEFTSHIFT:     /* 切换为大写字符 */
            bcrinfo->asc = upper_asc;
            break;

        default:                /* 保存字符 */
            bcrinfo->code[bcrinfo->index++] = bcrinfo->asc[ie.code];
            bcrinfo->asc = lower_asc;
            break;
        }
    }

    return NULL;
}

/**************************************************************************************************
 * @brief  : 扫码枪注册接口
 * @param  : None
 * @return : None
**************************************************************************************************/
static int _barcode_reader_init(bcr_cb cb)
{
    int ret;
    barcode_reader_context *cxt = &bcr_cxt;

    /* 保存回调 */
    cxt->report = cb;

    /* 打开设备 */
    cxt->fd = open(BCR_DEV, O_RDONLY);
    CHECK_R(cxt->fd < 0, cxt->fd, "open %s dev fail reason = %d", BCR_DEV, cxt->fd);

    /* 创建扫码枪线程 */
    ret = pthread_create(&cxt->pid, NULL, bcr_thread_entry, NULL);
    CHECK_R(ret < 0, ret, "create barcode reader therad fail reason = %d", ret);

    return 0;
}

static barcode_reader_ops bcr_ops = {
    .init = _barcode_reader_init,
};


/**************************************************************************************************
 * @brief  : 获取扫码枪操作函数
 * @param  : None
 * @return : None
**************************************************************************************************/
barcode_reader_ops *get_barcode_reader_ops(void)
{
    return &bcr_ops;
}

/**************************************************************************************************
 * @brief  : 扫码枪回调
 * @param  : None
 * @return : None
**************************************************************************************************/
static void barcode_reader_cb(char *code)
{
    printf("result = %s\n", code);
}

/**************************************************************************************************
 * @brief  : 测试代码
 * @param  : None
 * @return : None
**************************************************************************************************/
int main(int argc, char const *argv[])
{
    get_barcode_reader_ops()->init(barcode_reader_cb);
    pthread_join(bcr_cxt.pid, NULL);
    return 0;
}
