#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include "codestd.h"

extern void do_initcalls(void);

int main(int argc, char const *argv[])
{
    do_initcalls();
    printf("hello world\n");
    return 0;
}

