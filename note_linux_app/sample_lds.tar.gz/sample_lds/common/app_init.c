#include "codestd.h"
#include "app_init.h"

extern initcall_t __usr_init_start[];
extern initcall_t __usr_init0_start[];
extern initcall_t __usr_init1_start[];
extern initcall_t __usr_init2_start[];
extern initcall_t __usr_init3_start[];
extern initcall_t __usr_init_end[];

static initcall_t *initcall_levels[] = {
        __usr_init0_start,
        __usr_init1_start,
        __usr_init2_start,
        __usr_init3_start,
        __usr_init_end,
};

static void do_initcall_level(int level)
{
        initcall_t *fn;
 
        for (fn = initcall_levels[level]; fn < initcall_levels[level+1]; fn++)
                (*fn)();
}
 
void do_initcalls(void)
{
        int level;
 
        for (level = 0; level < ARRAY_SIZE(initcall_levels) - 1; level++)
                do_initcall_level(level);
}
