#ifndef __APP_INIT_H__
#define __APP_INIT_H__

/* 定义init call */
#  define __used			__attribute__((__used__))

typedef int (*initcall_t)(void);
#define __define_initcall(fn, level) \
	static initcall_t __initcall_##fn##level __used\
	__attribute__((__section__(".usr_init_" #level))) = fn;

/* 定义级别 */
#define dev_initcall(fn)		__define_initcall(fn, 0)
#define app_initcall(fn)		__define_initcall(fn, 1)
#define fun_initcall(fn)		__define_initcall(fn, 1s)
#define zwd_initcall(fn)		__define_initcall(fn, 2)
#define aaa_initcall(fn)		__define_initcall(fn, 2s)
#define bbb_initcall(fn)		__define_initcall(fn, 3)
#define ccc_initcall(fn)		__define_initcall(fn, 3s)



#endif
