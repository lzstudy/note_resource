#include <stdio.h>
#include "codestd.h"
#include "app_init.h"

int test0(void)
{
    LOG_I("%s", __func__);
    return 0;
}
dev_initcall(test0);

int test1(void)
{
    LOG_I("%s", __func__);
    return 0;
}
app_initcall(test1);

int test5(void)
{
    LOG_I("%s", __func__);
    return 0;
}
dev_initcall(test5);

int test2(void)
{
    LOG_I("%s", __func__);
    return 0;
}
fun_initcall(test2);

int test3(void)
{
    LOG_I("%s", __func__);
    return 0;
}
zwd_initcall(test3);

int test4(void)
{
    LOG_I("%s", __func__);
    return 0;
}
bbb_initcall(test4);