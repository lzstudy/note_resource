
#pragma once


void StartWinCrashRecored();
