void Demo(int a)
{
	int nMoveBit = -10;
	//负数参与位移运算
	int nMoveResult1 = a >> -2;

}