void Demo()
{
	bool b = true;
	//在布尔变量使用自增运算
	b++;
}