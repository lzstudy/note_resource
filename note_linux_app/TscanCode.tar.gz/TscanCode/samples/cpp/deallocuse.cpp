//检测一种Objective C中的内存释放后使用问题
dealloc ; use_ ;