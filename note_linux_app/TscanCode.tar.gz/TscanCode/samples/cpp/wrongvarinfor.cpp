void Demo(int iMax)
{
	int j=0;
	//循环的时候使用了非控制循环的变量
	for(int i = 0; i < iMax; ++j)
	{
		
	} 
}