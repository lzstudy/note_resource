void Demo(int i)
{
	 i = i;
}