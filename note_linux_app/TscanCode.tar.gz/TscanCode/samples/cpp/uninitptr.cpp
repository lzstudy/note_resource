void Demo()
{
    Foo *p;
	//未初始化指针
    p->Method();
}