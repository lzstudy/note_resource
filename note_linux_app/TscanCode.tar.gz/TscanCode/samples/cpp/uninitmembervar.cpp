class C
{
public:
	C()
	: a(0)
	//成员变量b没有初始化
	{
	}
private:
	int a;
	int b;
};