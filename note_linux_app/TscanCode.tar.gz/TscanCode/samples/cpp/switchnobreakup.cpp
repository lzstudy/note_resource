void Demo(int a)
{
	switch(a){
		case 1:
		break;
		case 2: //case 2没有break语句
		default;
		break;
	}
}