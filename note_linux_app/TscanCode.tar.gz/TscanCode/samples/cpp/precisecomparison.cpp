bool Demo(float f)
{
	//浮点数进行等号运算
	if (f == 0)
	{
		return true;
	}
	return false;
}