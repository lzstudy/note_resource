void Demo(int a,int b)
{
	// 存在完全相反的if条件
	if( a != 3 )//error
	{
		if( a == 3)
		{
		}
	}
}