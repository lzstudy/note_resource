int Demo()
{
	//数字上使用sizeof
	int ret = sizeof(10);
	return ret;
}