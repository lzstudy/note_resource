void Demo(unsigned int i)
{
	//无符号数不会小于0
	if (i < 0)
	{
		DoSomething();
	}
}