void Demo( int iMax )
{
	int iCount = 0;
	// i--应该是i++?
	for (int i = 1; i < iMax; i--)
	{
		iCount++;
	}
}