void Demo(bool b)
{
	//布尔值参与位运算
	int r = b & 0x01;
}