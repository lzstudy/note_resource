void Demo(int i)
{
	unsigned int j = 0;
	j = i;
}