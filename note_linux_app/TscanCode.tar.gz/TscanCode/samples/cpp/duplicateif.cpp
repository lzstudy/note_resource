int Demo(int a, int b)
{
	// if和elseif的条件是一样的
	if(a == b)
	{
		return 1;
	}
	else if(a == b)
	{
		return 2;
	}
	
	return 0;
}