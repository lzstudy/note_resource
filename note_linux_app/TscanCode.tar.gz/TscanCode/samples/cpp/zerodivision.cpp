int Demo()
{
	int	nZeroDivision = 10;
	int	nZero = 0;
	//除数是0
	int ret = nZeroDivision % nZero;
	return ret;
}