void Demo(std::string &str, std::string &search)
{
	// string的find返回的结果应该跟string::npos来判定
	if( 0 <= str.find(search))
	{
	}
}