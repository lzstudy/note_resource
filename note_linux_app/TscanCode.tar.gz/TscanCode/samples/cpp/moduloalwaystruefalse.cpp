void Demo(int a, int b)
{
	// a % 10不可能等于10
	if (a % 10 == 10)
	{
		a++;
	}
	else if (b * 1 == 10)
	{
		a--;
	}
}