void Demo(int x)
{
	int y = x & 4;
	if (y == 3) //条件总是不成立
	{
	}
}