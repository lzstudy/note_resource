// #pragma pack没有#pragam pop配对
#pragma pack(push, 1)

void func()
{
}