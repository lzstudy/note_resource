//检测一种Objective C中的内存释放问题
dealloc ; dealloc ;