void Demo(short count)
{
	// 自增变量i是char类型，但是count是short类型
	for (char i = 0; i < count; ++i)
	{

	}
}