void Demo( int iCount )
{
	// 应该是if(iCount == 0)??
	if ( iCount = 0 )
	{
		iCount = 2;
	}
}