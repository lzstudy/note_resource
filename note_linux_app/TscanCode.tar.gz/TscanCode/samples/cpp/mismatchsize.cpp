void Demo()
{
	//分配的内存空间不匹配
	int i = malloc(3);
}