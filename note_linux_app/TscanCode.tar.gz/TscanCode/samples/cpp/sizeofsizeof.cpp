void Demo()
{
	int a = 0;
	//重复使用sizeof
	int n = sizeof(sizeof(a));
}