void Demo()
{
	unsigned int b = 10;
	//负数参与除法运算
	int c = -1 / b;
}