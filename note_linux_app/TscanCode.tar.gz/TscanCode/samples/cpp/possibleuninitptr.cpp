void Demo()
{
	Foo *p;
	Foo *q = p;
}