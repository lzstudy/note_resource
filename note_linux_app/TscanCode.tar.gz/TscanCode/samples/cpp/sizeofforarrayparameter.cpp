int Demo(int sz[])
{
	// sizeof数组参数返回的是指针的大小，而不是数组大小
	return(sizeof(sz))	;
}