void Demo(int i, int j)
{
	// 正确的写法应该是:long long t = (long long)i * j;
	long long ll = i * j;
}