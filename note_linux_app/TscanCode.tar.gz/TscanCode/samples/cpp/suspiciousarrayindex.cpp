void Demo()
{
	if(i < m_shCycleGnaNumber)
	{
		//m_astCycleGnaInfo[m_shCycleGnaNumber]可能存在问题
		m_astCycleGnaInfo[i] = m_astCycleGnaInfo[m_shCycleGnaNumber];
	}
}