void Demo()
{
	int i=0;
	// assert函数里面进行赋值操作，存在风险
	assert(i=5);
}