void Demo(int n)
{
	int a;
	if (n > 10)
	{
		a = 10;
	}
	//a可能没有被赋值
	int b = a;
}