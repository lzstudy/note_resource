void Demo(int a, int b, bool c, bool d)
{
	// if-else分支的代码相同
	if (a == b)
	{
		c = DoSomething(1);
	} 
	else
	{
		c = DoSomething(1);
	}
}