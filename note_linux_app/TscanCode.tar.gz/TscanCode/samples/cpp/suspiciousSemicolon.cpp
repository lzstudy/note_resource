void Demo(int iMax)
{
	// if表达式后面的分号很有可能是多余的
	if ( iMax>0 && iMax != 3);
	{
		
	}
}