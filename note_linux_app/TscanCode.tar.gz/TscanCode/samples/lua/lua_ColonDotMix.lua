local t = {}
function t.new()
end
local inst = t:new() --error 函数声明使用的.，调用却使用的: