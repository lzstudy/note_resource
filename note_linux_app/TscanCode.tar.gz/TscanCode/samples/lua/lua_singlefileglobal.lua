--file1
f1 = function() end
--file2
f2 = function() end --这条规则已经废弃，不建议使用