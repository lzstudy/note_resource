local function GetBag(id)
	return id + 1
end

local function isBagNull(id)
	local size = GetBag(id)
end
--isBagNull函数需要至少一个参数，这里一个参数都没有填。
isBagNull() 