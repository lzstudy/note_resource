function Demo()
	-- t只在当前作用域使用，建议声明为local
	t = {} 
	t.a = 1
end