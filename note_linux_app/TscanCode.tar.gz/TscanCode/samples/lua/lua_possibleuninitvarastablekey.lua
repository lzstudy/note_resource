	function Demo()
		--MAX_LEVEL没有定义，但很可能是一个C++的宏
		return {MAX_LEVEL} 
	end