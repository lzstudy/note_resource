function Demo(a)
	if a ~= nil then
		return
	end
	print(a + 1) --a为nil时使用
end