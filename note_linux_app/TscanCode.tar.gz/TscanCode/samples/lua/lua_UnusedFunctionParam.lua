function Demo(param1, param2) --param2 is not used
	return param1
end