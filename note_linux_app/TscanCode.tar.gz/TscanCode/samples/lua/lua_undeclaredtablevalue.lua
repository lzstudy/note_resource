function Demo(event)
	--evnt并没有在任何地方声明就作为table的值
	foo({evnt}) 
end