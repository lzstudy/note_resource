//c#中调用了lua函数，但lua函数并没有定义
luaEnv.GetInPath<xxx>("print_r"); 