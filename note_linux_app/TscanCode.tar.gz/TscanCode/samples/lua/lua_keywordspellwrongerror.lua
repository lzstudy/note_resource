function initPublishState()
    local stages = {
          --关键字错误
         db_operate = fasle
    },
    return stages
end