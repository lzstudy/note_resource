	function Demo()
		--这里少了一个括号。工具只能检查有限的语法错误。
		foo({name='ben', sex='male'} 
	end