function Demo(event)
	--evnt并没有在任何地方声明就赋值给其他变量
	local b = evnt 
end