function Use()
	print(a + 1) --变量的使用出现在变量的定义之前
end
function Decl()
	a = 1
end