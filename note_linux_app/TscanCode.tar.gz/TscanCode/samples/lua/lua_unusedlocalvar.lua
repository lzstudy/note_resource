function Demo(param1, param2)
	local a = param1 + param2  --变量声明了再也没有使用
end