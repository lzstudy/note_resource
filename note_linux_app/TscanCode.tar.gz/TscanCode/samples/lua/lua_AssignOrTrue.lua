function Demo(param)
	p = param or true --p总是为true， 不论param是true还是false
end