function RecursiveFunc1()
	--无任何条件调用自己。检测特定的问题
	RecursiveFunc1() 
end