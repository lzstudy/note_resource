function Demo(event)
	--evnt并没有在任何地方声明就作为print函数的参数使用
	print(evnt) 
end