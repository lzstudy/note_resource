--evnt并没有在任何地方声明就使用了
function Demo(event)
	print(evnt + 1) 
end