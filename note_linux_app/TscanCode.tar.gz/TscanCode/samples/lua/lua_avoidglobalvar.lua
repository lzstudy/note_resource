t = {}
function t.Demo()
	function tmp() --临时变量，建议使用局部变量
	end
	tmp()
end