function Demo()
	--EditorApplication.NewScene在unity中标记为Obsolete,不建议使用
	local  scene = CS.EditorApplication.NewScene 
end