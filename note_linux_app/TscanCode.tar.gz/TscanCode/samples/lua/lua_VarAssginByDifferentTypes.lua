function Demo()
	t = {} 
end

function Demo2()
	--同一个变量t在两个不同的作用域赋予不同的类型，非推荐的写法
	t = "" 
end