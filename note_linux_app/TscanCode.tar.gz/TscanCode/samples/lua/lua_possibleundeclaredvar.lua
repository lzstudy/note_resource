function Demo(event)
	--OtherLanguageVar没有申明，但是是驼峰命名法，可能是其他语言导出的变量
	local b = OtherLanguageVar + 1
end