class C
{
	int Demo(int a, int b)
	{
		//整数相成可能出现数值溢出
		int l = a * b;
		return l;
	}
}