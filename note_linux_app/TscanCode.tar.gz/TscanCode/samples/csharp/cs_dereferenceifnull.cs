public void Demo(A myA)
{
	int a = 0;
	if (myA == null)
	{
		//判定了myA为空使用，可能条件写错了
		a = myA.a;
	}
}