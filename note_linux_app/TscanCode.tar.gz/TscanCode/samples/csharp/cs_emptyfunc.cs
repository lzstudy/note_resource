class C : MonoBehaviour
{
	//空函数可能会影响性能，建议删除
	public void Func() 
	{

	}
}