class C:MonoBehaviour
{
	//Unity项目中，不应该出现空的Update函数, 这会影响性能
	public Update() 
	{
	}
}