class C : MonoBehaviour
{
	//mono子类成员不能命名为m_Name
	public int m_Name;  

	public void Func()
	{

	}
}