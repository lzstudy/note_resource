class C : MonoBehaviour
{
	public Demo() 
	{
		//Unity项目中，避免使用foreach
		foreach (var i in m_list)
		{
		}
	}
}