class C
{
	public void Demo()
	{
		int nLogic = fRetVale();
		//条件恒为假
		if ((nLogic > 10) && (nLogic < 9)) 
		{                   
			Console.WriteLine("Error");
		}
	}
}