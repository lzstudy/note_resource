class C
{
	public void Demo()
	{
		//格式化需要两个参数，实际只传入一个参数
		string str_cur = 
			string.Format("nothing{sss},string{120}", str);
	}
}