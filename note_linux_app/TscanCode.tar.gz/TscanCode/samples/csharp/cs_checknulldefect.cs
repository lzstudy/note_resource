class C
{
	void Demo(Object obj)
	{
		//if条件的逻辑关系应该是or
		if (obj == null and obj.mem)
		{
		}
	}
}