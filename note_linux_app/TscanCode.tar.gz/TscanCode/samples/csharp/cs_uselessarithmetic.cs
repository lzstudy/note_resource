class C
{
	public Demo()
	{
		//使用1参与模运算是无效的
		long c=a%1;  
	}
}