class C : MonoBehaviour
{
	//Unity项目中，mono子类不应该实现自己的构造函数
	public CS_UnsafeConstructor() 
	{
		DoSomething();
	}
}