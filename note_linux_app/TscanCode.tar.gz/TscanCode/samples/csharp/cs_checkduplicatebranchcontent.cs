class  C
{
	public void Demo(int flag)
	{
		if (flag>1)
		{
			Console.WriteLine("1");
		}
		else	
		{
			//不同分支的内容是一样的，要么分支是多余的，要么有分支出现问题
			Console.WriteLine("1"); 
		}
	}
}