#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <asm/types.h>
#include <linux/videodev2.h>
#include <sys/mman.h>
#include <errno.h>
#include <stdint.h>
#include "codestd.h"

#define VB2_BUF_COUNT			5												/**< 申请的缓冲数量. */
#define PLANE_COUNT				2												/**< PLANE数量. */

typedef struct _vidoe_buf_info {
	void *start[PLANE_COUNT];													/**@ mmap地址. */
	struct v4l2_plane plane[PLANE_COUNT];										/**@ plane信息. */
}video_buf_info;

typedef struct _camera_handle {
	int fd;																		/**@ 文件描述符. */
	uint16_t res_x;																/**@ x分辨率. */
	uint16_t res_y;																/**@ y分辨率. */
	video_buf_info vb[VB2_BUF_COUNT];											/**@ 缓冲区信息. */
}camera_handle;

static camera_handle cam_handle;												/**# 摄像头句柄. */

/**************************************************************************************************
 * @brief  : 断点
 * @param  : 设备
 * @return : 0成功, -1失败
**************************************************************************************************/
static void break_line(void)
{
    char buf[5];
    printf("current pid = %d\n", getpid());
    printf("wait signal : ");
    scanf("%d", &buf[0]);
}

/**************************************************************************************************
 * @brief  : 参数初始化
 * @param  : 设备
 * @return : 0成功, -1失败
**************************************************************************************************/
static void arg_init(int argc, char const *argv[])
{
	camera_handle *handle = &cam_handle;

	handle->res_x = atoi(argv[1]);
	handle->res_y = atoi(argv[2]);
}

/**************************************************************************************************
 * @brief  : 摄像头初始化
 * @param  : 设备
 * @return : 0成功, -1失败
**************************************************************************************************/
static int cam_init(const char *dev)
{
	int ret;
	enum v4l2_buf_type type;

	struct v4l2_buffer buf = {0};
	struct v4l2_format fmt = {0};
	struct v4l2_input input = {0};
	struct v4l2_capability cap = {0};
	struct v4l2_requestbuffers req = {0};

	camera_handle *handle = &cam_handle;

	/* 打开设备失败 */
	handle->fd = open(dev, O_RDWR);
	CHECK_E(handle->fd < 0, "open %s fail", dev);

	/* 查询可用的设备 */
	input.index = 0;
	while (ioctl (handle->fd, VIDIOC_ENUMINPUT, &input) == 0) {
		printf("input : %s, std: %ld\n", input.name, input.std);
		input.index++;
	}

	/* 设置输入设备 */
	input.index = 0;
	ret = ioctl(handle->fd, VIDIOC_S_INPUT, &input);
	CHECK_R(ret < 0, ret , "VIDIOC_S_INPUT fail %d", ret);

	/* 查询设备能力 */
	ret = ioctl(handle->fd, VIDIOC_QUERYCAP, &cap);
	CHECK_R(ret < 0, ret , "VIDIOC_QUERYCAP fail %d", ret);

	/* 设置帧格式 */
	fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	fmt.fmt.pix_mp.width = handle->res_x;
	fmt.fmt.pix_mp.height = handle->res_y;
	fmt.fmt.pix_mp.pixelformat = V4L2_PIX_FMT_NV21M;
	fmt.fmt.pix_mp.field = V4L2_FIELD_NONE;
	fmt.fmt.pix_mp.num_planes = PLANE_COUNT;
	ret = ioctl(handle->fd, VIDIOC_S_FMT, &fmt);
	CHECK_R(ret < 0, ret , "VIDIOC_S_FMT fail %d", ret);

	/* 申请VB2_BUF */
	req.count = VB2_BUF_COUNT;
	req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	req.memory = V4L2_MEMORY_MMAP;
	ret = ioctl(handle->fd, VIDIOC_REQBUFS, &req);
	CHECK_R(ret < 0, ret , "VIDIOC_REQBUFS fail %d", ret);

	for(uint8_t i = 0 ; i < VB2_BUF_COUNT ; i++)
	{
		/* querybuf */
		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
		buf.memory = V4L2_MEMORY_MMAP;
		buf.m.planes = handle->vb[i].plane;
		buf.length = PLANE_COUNT;
		buf.index = i;
		ret = ioctl(handle->fd, VIDIOC_QUERYBUF, &buf);
		CHECK_R(ret < 0, ret, "VIDIOC_QUERYBUF fail %d", ret);

		/* 映射plane  */
		for(uint8_t j = 0 ; j < PLANE_COUNT ; j++)
		{
			handle->vb[i].start[j] = mmap(NULL, handle->vb[i].plane[j].length, PROT_READ | PROT_WRITE, MAP_SHARED, handle->fd, handle->vb[i].plane[j].m.mem_offset);
			CHECK_E(handle->vb[i].start[j] == NULL, "mmap fail");
		}
	}

	/* 入队 */
	for(uint8_t i = 0 ; i < VB2_BUF_COUNT ; i++)
	{
		memset(&buf, 0, sizeof(buf));

		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
		buf.memory = V4L2_MEMORY_MMAP;
		buf.length = PLANE_COUNT;
		buf.index = i;
		buf.m.planes = handle->vb[i].plane;
		ret = ioctl(handle->fd, VIDIOC_QBUF, &buf);
		CHECK_R(ret < 0, ret , "VIDIOC_QBUF fail %d", ret);
	}

	/* 启动流模式 */
	type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	ret = ioctl(handle->fd, VIDIOC_STREAMON, &type);
	CHECK_R(ret < 0, ret , "VIDIOC_STREAMON fail %d", ret);

	LOG_I("cam init ok");
}

/**************************************************************************************************
 * @brief  : 处理摄像头业务
 * @param  : 文件
 * @return : 0成功, -1失败
**************************************************************************************************/
static void cam_work(void)
{
	int ret, num = 0;
	fd_set fds;
	struct timeval tv;
	struct v4l2_buffer buf;
	enum v4l2_buf_type type;
	struct v4l2_plane *tmp_plane;
	struct plane_start* plane_start;
	camera_handle *handle = &cam_handle;
	void *start;

	/* 申请临时的plane */
	tmp_plane = calloc(PLANE_COUNT, sizeof(*tmp_plane));
	FILE *file_fd = fopen("zw.yuv", "wb+");

	while(1)
	{
		FD_ZERO(&fds);
		FD_SET(handle->fd, &fds);

		tv.tv_sec = 5;
		tv.tv_usec = 0;

		ret = select(handle->fd + 1, &fds, NULL, NULL, &tv);
		if(ret == -1)
			continue;
		if(ret == 0)
			exit(1);

		/* 取帧 */
		memset(&buf, 0, sizeof(buf));
		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
		buf.memory = V4L2_MEMORY_MMAP;
		buf.m.planes = tmp_plane;
		buf.length = PLANE_COUNT;
		ret = ioctl(handle->fd, VIDIOC_DQBUF, &buf);
		CHECK_E(ret < 0, "VIDIOC_DQBUF fail %d", ret);

		// LOG_I("create frame %d", num);

		for (uint8_t j = 0; j < PLANE_COUNT; j++) {
			start = handle->vb[buf.index].start[j];
			ret = fwrite(start, tmp_plane[j].bytesused, 1, file_fd);
		}

		num++;
		if(num >= 10)
			break;

		/* 还帧 */
		ret = ioctl(handle->fd, VIDIOC_QBUF, &buf);
		CHECK_E(ret < 0, "VIDIOC_QBUF fail %d", ret);
	}

	/* 关闭流 */
	type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	ret = ioctl(handle->fd, VIDIOC_STREAMOFF, &type);
	CHECK_E(ret < 0, "VIDIOC_STREAMOFF fail %d", ret);

	free(tmp_plane);
	fclose(file_fd);
}

/**************************************************************************************************
 * @brief  : 主函数入口
 * @param  : 文件
 * @return : 0成功, -1失败
**************************************************************************************************/
int main(int argc, char const *argv[])
{
	arg_init(argc, argv);
	cam_init("/dev/video1");
	cam_work();
	return 0;
}
