#ifndef __CODESTD_H__
#define __CODESTD_H__

/* 判断并返回 */
#define CHECK_R(cond, val, fmt, ...) \
    do {if(cond) {printf(fmt"\n", ##__VA_ARGS__); return val;}} while(0)

#define CHECK_RET(cond, val) \
    do {if(cond) {return val;}} while(0)

/* 判断并GOTO */
#define CHECK_G(cond, val, fmt, ...) \
    do {if(cond) {printf(fmt"\n", ##__VA_ARGS__); goto val;}} while(0)

#define CHECK_GOTO(cond, val) \
    do {if(cond) {goto val;}} while(0)

/* 判断并退出 */
#define CHECK_E(cond, fmt, ...) \
    do {if(cond) {printf(fmt"\n", ##__VA_ARGS__); exit(1);}} while(0)

/* 打印信息 */
#define LOG_I(fmt, ...)          printf(fmt"\n", ##__VA_ARGS__);

#endif
