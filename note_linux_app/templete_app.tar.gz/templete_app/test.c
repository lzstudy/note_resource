#include <stdio.h>
#include <pthread.h>
#include "codestd.h"

static pthread_t pid;

/**************************************************************************************************
 * @brief  : 线程入口
 * @param  : None
 * @return : None
**************************************************************************************************/
static void *motor_event_monitor_thread(void *arg)
{
    return 0;
}

/**************************************************************************************************
 * @brief  : 线程初始化
 * @param  : None
 * @return : None
**************************************************************************************************/
static int thread_init(void)
{
    int ret;

    ret = pthread_create(&pid, NULL, motor_event_monitor_thread, NULL);
    CHECK_R(ret < 0, ret, "thread create fail err = %d", ret);

    pthread_detach(pid);
    return 0;
}

/**************************************************************************************************
 * @brief  : 主函数入口
 * @param  : None
 * @return : None
**************************************************************************************************/
int main(int argc, char const *argv[])
{
    thread_init();
    /* code */
    return 0;
}
