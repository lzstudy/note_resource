#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <alsa/asoundlib.h>
#include "codestd.h"

#define SND_PERIOD_SIZE         1024                                            /**< 周期为1024帧. */
#define SND_PERIODS             16                                              /**< 周期数， 驱动buffer数量. */

#define SND_PLAYBACK_DEV        "hw:2,1"                                        /**< 播放设备. */

typedef struct _riff_chunk {
    char id[4];                                                                 /**@ id, 固定RIFF. */
    uint32_t size;                                                              /**@ wav文件大小. */
    char type[4];                                                               /**@ 类型. */
}__attribute__((packed)) riff_chunk;

typedef struct _format_chunk {
    char id[4];                                                                 /**@ 固定fmt. */
    uint32_t size;                                                              /**@ 固定16. */
    uint16_t format;                                                            /**@ 固定1. */
    uint16_t channel;                                                           /**@ mono = 1, stereo = 2. */
    uint32_t srate;                                                             /**@ 采样率 */
    uint32_t brate;                                                             /**@ 每秒字节数. */
    uint16_t align;                                                             /**@ 块对齐. */
    uint16_t bps;                                                               /**@ 采样位数. */
}__attribute__ ((packed)) format_chunk;

typedef struct data_chunk {
    char id[4];                                                                 /**@ 固定data. */
    uint32_t size;                                                              /**@ 大小. */
}__attribute__ ((packed)) data_chunk;

typedef struct _wav_chunk {
    riff_chunk riff;                                                            /**@ riff chunk. */
    format_chunk fmt;                                                           /**@ fmt chunk. */
    data_chunk data;                                                            /**@ data chunk. */
}__attribute__ ((packed)) wav_chunk;

typedef struct snd_context {
    int fd;                                                                     /**@ 打卡的wav文件. */
    wav_chunk chunk;                                                            /**@ wav chunk. */
    snd_pcm_t *pcm;                                                             /**@ pcm句柄. */
    uint8_t *buf;                                                               /**@ 缓冲区. */
    uint32_t size;                                                              /**@ 缓冲区大小. */
}snd_context;

static snd_context snd_cxt;

/**************************************************************************************************
 * @brief  : 声卡配置
 * @param  : None
 * @return : None
**************************************************************************************************/
static int snd_card_config(snd_context *cxt)
{
    int ret;
    snd_pcm_t *pcm;
    snd_pcm_hw_params_t *sphp;
    wav_chunk *chunk = &cxt->chunk;

    /* 打开设备 */
    ret = snd_pcm_open(&pcm, SND_PLAYBACK_DEV, SND_PCM_STREAM_PLAYBACK, 0);
    CHECK_RET(ret < 0, ret, "snd %s open fail(%d)", SND_PLAYBACK_DEV, ret);

    /* 创建SPHP */
    snd_pcm_hw_params_malloc(&sphp);

    /* 获取当前硬件配置 */
    ret = snd_pcm_hw_params_any(pcm, sphp);
    CHECK_GOTO(ret < 0, err_to_free_pcm, "get pcm param fail(%d)", ret);

    /* 设置访问类型：交错模式 */
    ret = snd_pcm_hw_params_set_access(pcm, sphp, SND_PCM_ACCESS_RW_INTERLEAVED);
    CHECK_GOTO(ret < 0, err_to_free_sphp, "snd set sphp fail(%d)", ret);

    /* 设置数据格式：有符号16位、小端模式 */
    ret = snd_pcm_hw_params_set_format(pcm, sphp, SND_PCM_FORMAT_S16_LE);
    CHECK_GOTO(ret < 0, err_to_free_sphp, "set format fail(%d)", ret);

    /* 设置采样率 */
    ret = snd_pcm_hw_params_set_rate(pcm, sphp, chunk->fmt.srate, 0);
    CHECK_GOTO(ret < 0, err_to_free_sphp, "set rate fail(%d)", ret);

    /* 设置通道 */
    ret = snd_pcm_hw_params_set_channels(pcm, sphp, chunk->fmt.channel);
    CHECK_GOTO(ret < 0, err_to_free_sphp, "set snd channel fail(%d)", ret);

    /* 设置周期大小 */
    ret = snd_pcm_hw_params_set_period_size(pcm, sphp, SND_PERIOD_SIZE, 0);
    CHECK_GOTO(ret < 0, err_to_free_sphp, "set set period fail(%d)", ret);

    /* 设置周期数 */
    ret = snd_pcm_hw_params_set_periods(pcm, sphp, SND_PERIODS, 0);
    CHECK_GOTO(ret < 0, err_to_free_sphp, "set set periods fail(%d)", ret);

    /* 使能配置 */
    ret = snd_pcm_hw_params(pcm, sphp);
    CHECK_GOTO(ret < 0, err_to_free_sphp, "enable pcm hw param fail(%d)", ret);

    /* 申请应用缓冲 */
    cxt->size = SND_PERIOD_SIZE * chunk->fmt.align;
    cxt->buf = malloc(cxt->size);
    CHECK_GOTO(cxt->buf == NULL, err_to_free_sphp, "snd malloc buf fail");

    /* 释放参数缓冲 */
    snd_pcm_hw_params_free(sphp);

    /* 保存参数 */
    cxt->pcm = pcm;
    LOG_I("snd init ok.");
    return 0;

err_to_free_sphp:
    snd_pcm_hw_params_free(sphp);
err_to_free_pcm:
    snd_pcm_close(pcm);
    return ret;
}

/**************************************************************************************************
 * @brief  : 打印PCM信息
 * @param  : None
 * @return : None
**************************************************************************************************/
static void print_wav_chunk(wav_chunk *chunk)
{
    /* 打印riff */
    LOG_I("============ riff chunk ============");
    LOG_I("id = %s\r\n", chunk->riff.id);
    LOG_I("size = %d", chunk->riff.size);
    LOG_I("type = %s", chunk->riff.type);

    /* 打印fmt */
    LOG_I("============ fmt chunk ============");
    LOG_I("id = %s", chunk->fmt.id);
    LOG_I("size = %d", chunk->fmt.size);
    LOG_I("format = %d", chunk->fmt.format);
    LOG_I("channel = %d", chunk->fmt.channel);
    LOG_I("srate = %d", chunk->fmt.srate);
    LOG_I("brate = %d", chunk->fmt.brate);
    LOG_I("align = %d", chunk->fmt.align);
    LOG_I("bps = %d", chunk->fmt.bps);

    /* 打印data */
    LOG_I("============ data chunk ============");
    LOG_I("id = %s\r\n", chunk->data.id);
    LOG_I("size = %d", chunk->data.size);
}

/**************************************************************************************************
 * @brief  : 解析音频文件的riff
 * @param  : None
 * @return : None
**************************************************************************************************/
static int parse_wav_riff(snd_context *cxt, const char *file)
{
    int ret;
    wav_chunk *chunk = &cxt->chunk;

    /* 打开音频文件 */
    cxt->fd = open(file, O_RDONLY);
    CHECK_RET(cxt->fd < 0, cxt->fd, "open %s wav file fail(%d)", file, cxt->fd);

    /* 读取chunk */
    ret = read(cxt->fd, chunk, sizeof(*chunk));
    CHECK_GOTO(ret < 0, err_to_close_file, "read wav chunk fail(%d)", ret);

    print_wav_chunk(chunk);

    LOG_I("parse wav riff ok.");
    return 0;

err_to_close_file:
    close(cxt->fd);
    return ret;
}

/**************************************************************************************************
 * @brief  : 播放wav音频
 * @param  : None
 * @return : None
**************************************************************************************************/
static void play_wav_audio(snd_context *cxt)
{
    int ret;

    lseek(cxt->fd, sizeof(wav_chunk) + 1024 * 20, SEEK_SET);

    for(;;)
    {
        /* 读取PCM数据 */
        memset(cxt->buf, 0, cxt->size);
        ret = read(cxt->fd, cxt->buf, cxt->size);
        CHECK_GOTO_EX(ret <= 0, err_out);

        LOG_I("ret = %d", ret);

        /* 写入声卡设备 */
        ret = snd_pcm_writei(cxt->pcm, cxt->buf, SND_PERIOD_SIZE);
        CHECK_GOTO_EX(ret < 0, err_out);

        /* 更换位置 */
        ret= lseek(cxt->fd, (ret - SND_PERIOD_SIZE) * cxt->chunk.fmt.align, SEEK_CUR);
        CHECK_GOTO_EX(ret < 0, err_out);
   }

err_out:
    sleep(5);
    free(cxt->buf);
    snd_pcm_close(cxt->pcm);
    close(cxt->fd);
    exit(EXIT_FAILURE);
}

/**************************************************************************************************
 * @brief  : 测试程序
 * @param  : None
 * @return : None
**************************************************************************************************/
int main(int argc, char const *argv[])
{
    parse_wav_riff(&snd_cxt, argv[1]);
    snd_card_config(&snd_cxt);
    play_wav_audio(&snd_cxt);
    return 0;
}

