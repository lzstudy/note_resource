#ifndef __TEST_H__
#define __TEST_H__

void test_func1(void);
void test_func2(void);
#endif
