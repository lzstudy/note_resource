#include <stdio.h>
#include <pthread.h>
#include "codestd.h"
#include "print.h"

void test_func1(void)
{
    int i = 0;
    printf("enter test 1 func\n");
    i++;
    printf("i = %d\n", i);
}


void test_func2(void)
{
    printf("enter test 2 func\n");
}
